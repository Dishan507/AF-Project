const express=require('express');
const app=express();
const bodyParser=require('body-parser');
const cors=require('cors');
const mogoose=require('mongoose');
const assignmentsRoutes=express.Router();
const PORT =5000;
let Courses =require('./courses.model');

app.use(cors());
app.use(bodyParser.json());

mogoose.connect('mongodb://127.0.0.1:27017/courses',{useNewUrlParser:true});
const connection=mogoose.connection;
connection.once('open', function () {
    console.log('MongoDB connection established successfully');
});

assignmentsRoutes.route('/').get(function(req,res){
    Courses.find(function (err,courses) {
        if(err){
            console.log(err);
        }
        else{
            res.json(courses)
        }
    });
});

assignmentsRoutes.route('/:id').get(function (req,res) {
    let id=req.params.id;
    Courses.findById(id,function (err,courses) {
        res.json(courses);
    });
});

assignmentsRoutes.route('/add').post(function (req,res) {
    let courses=new Courses(req.body);
    courses.save()
        .then(courses =>{
            res.status(200).json({'courses':'courses added successfully'});
        })
        .catch(err => {
            res.status(400).send('adding new courses failed');
        });
});

assignmentsRoutes.route('/update/:id').put(function (req,res) {
    Courses.findById(req.params.id,function (err,courses) {
        if(!courses){
            res.status(404).send('data is not found');
        }
        else{
            courses.courseNameId=req.body.courseNameId;

            courses.save().then(courses => {
                res.json('courses updated');
            })
                .catch(err => {
                    res.status(400).send('Update not possible');
                });
        }
    });
});

assignmentsRoutes.route('/delete/:id').delete(function (req,res) {
    Courses.findById(req.params.id,function (err,courses) {
        if(!courses){
            res.status(404).send('data is not found');
        }
        else{
            courses.remove(req.params.id).then(courses=>{
                res.json('courses deleted');
            })
                .catch(err=>{
                    res.status(400).send('Delete not possible');
                });
        }
    });
});

app.use('/courses',assignmentsRoutes);

app.listen(PORT,function () {
    console.log("Server is running on PORT: "+PORT);
});


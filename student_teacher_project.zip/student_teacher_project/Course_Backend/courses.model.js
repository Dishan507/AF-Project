const mongoose=require('mongoose');
const Schema=mongoose.Schema;
let Courses =new Schema({
    courseNameId:{
        type:String
    }
});
module.exports=mongoose.model('Courses',Courses);
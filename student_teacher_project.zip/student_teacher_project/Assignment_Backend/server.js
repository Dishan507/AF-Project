const express=require('express');
const app=express();
const bodyParser=require('body-parser');
const cors=require('cors');
const mogoose=require('mongoose');
const assignmentsRoutes=express.Router();
const PORT =4000;
let Assignment =require('./assignment.model');

app.use(cors());
app.use(bodyParser.json());

mogoose.connect('mongodb://127.0.0.1:27017/assignments',{useNewUrlParser:true});
const connection=mogoose.connection;
connection.once('open', function () {
    console.log('MongoDB connection established successfully');
});

assignmentsRoutes.route('/').get(function(req,res){
    Assignment.find(function (err,assignments) {
        if(err){
            console.log(err);
        }
        else{
            res.json(assignments)
        }
    });
});

assignmentsRoutes.route('/:id').get(function (req,res) {
    let id=req.params.id;
    Assignment.findById(id,function (err,assignments) {
        res.json(assignments);
    });
});

assignmentsRoutes.route('/add').post(function (req,res) {
    let assignments=new Assignment(req.body);
    assignments.save()
        .then(assignments =>{
            res.status(200).json({'assignment':'assignments added successfully'});
        })
        .catch(err => {
            res.status(400).send('adding new assignment failed');
        });
});

assignmentsRoutes.route('/update/:id').put(function (req,res) {
    Assignment.findById(req.params.id,function (err,assignments) {
        if(!assignments){
            res.status(404).send('data is not found');
        }
        else{
            assignments.assignmentName=req.body.assignmentName;
            assignments.courseName=req.body.courseName;
            assignments.deuDate = req.body.deuDate;
            assignments.uploadFile=req.body.uploadFile;
            assignments.assignmentMarks=req.body.assignmentMarks;

            assignments.save().then(assignments => {
                res.json('Assignment updated');
            })
                .catch(err => {
                    res.status(400).send('Update not possible');
                });
        }
    });
});

assignmentsRoutes.route('/delete/:id').delete(function (req,res) {
    Assignment.findById(req.params.id,function (err,assignments) {
        if(!assignments){
            res.status(404).send('data is not found');
        }
        else{
            assignments.remove(req.params.id).then(assignments=>{
                res.json('Assignment deleted');
            })
                .catch(err=>{
                    res.status(400).send('Delete not possible');
                });
        }
    });
});

app.use('/assignments',assignmentsRoutes);

app.listen(PORT,function () {
    console.log("Server is running on PORT: "+PORT);
});


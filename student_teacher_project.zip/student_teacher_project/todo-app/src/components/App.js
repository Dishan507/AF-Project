'use strict';
import React from 'react';
import {BrowserRouter as Router, Route, Link} from 'react-router-dom';
import * as ReactDOM from "react-dom";
import ListAssignment from "./Assignment-List.component"
import EditAssignment from "./Assignment-Edit.component"
import CreateAssignment from "./Assignment-Create.component"
import DeleteAssignment from "./Assignment-Delete.component"
import 'filepond/dist/filepond.min.css';
ReactDOM.render((
    <Router>
        <Route path="/" exact component={ListAssignment}/>
        <Route path="/editAssignment/:id" exact component={EditAssignment}/>
        <Route path="/createAssignment" exact component={CreateAssignment}/>
        <Route path="/deleteAssignment/:id" exact component={DeleteAssignment}/>
    </Router>
), document.getElementById('root'));





